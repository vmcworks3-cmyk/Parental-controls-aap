# ParentalControlApp

Transparent Android parental-control starter project.

Included in v1:
- App-usage display
- Foundation for daily screen-time limits
- Foundation for bedtime scheduling
- Foundation for selected-app blocking
- Parent PIN can be added to settings
- Child-device controls are intended to remain visible and transparent

Not included:
- Hidden spying
- Reading private messages/passwords
- Covert camera/microphone access
- Secret tracking

## Build without Android Studio

This repository is designed for GitHub Actions. Push the project to a GitHub repository named `ParentalControlApp`.

The workflow builds a debug APK and publishes it as the `parental-control-apk` artifact.
